# Tailrace

Canal conditions, major/minor times and a shared catch log for the Twizel canals.
Installable on a phone (PWA) and laid out for desktop.

## Deploy (about 5 minutes, from your own computer)

The Netlify site `tailrace` already exists in your account (site id `d06bb111-ece6-49ba-b13a-ceec2ba69deb`).

1. Install Node.js 20+ from nodejs.org.
2. Unzip this folder, open a terminal inside it, then run:

       npm install
       npx netlify-cli login
       npx netlify-cli link --id d06bb111-ece6-49ba-b13a-ceec2ba69deb
       npx netlify-cli deploy --prod

3. Open https://tailrace.netlify.app, make an account, log a fish.

## Optional: invite code
In Netlify > Site configuration > Environment variables, add `SIGNUP_CODE` (any word).
New accounts then need that code. Leave it unset for open sign-up.

## Put it on a phone
Open the site, then: iPhone Safari > Share > Add to Home Screen.
Android Chrome > menu > Install app.

## Tests
    npm test                      # API + moon maths
    node test/serve.mjs           # local server with in-memory data on :8899

## Notes
- Data lives in Netlify Blobs (accounts, catches, photos). No database to set up.
- Gate/flow status is a link-out to Meridian; they don't publish canal gate data in a readable form.
- Spot coordinates in public/js/conditions.js are approximate (weather is area-level).
